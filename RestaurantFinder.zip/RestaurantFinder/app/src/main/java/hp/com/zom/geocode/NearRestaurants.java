package hp.com.zom.geocode;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NearRestaurants {

    @SerializedName("location")
    @Expose
    private Location location;
    @SerializedName("popularity")
    @Expose
    private Popularity popularity;
    @SerializedName("link")
    @Expose
    private String link;
    @SerializedName("nearby_restaurants")
    @Expose
    private final List<NearbyRestaurant> nearbyRestaurants = null;

    public List<NearbyRestaurant> getNearbyRestaurants() {
        return nearbyRestaurants;
    }

}