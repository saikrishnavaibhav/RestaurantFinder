package hp.com.zom.cuisine;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Cuisines {

    @SerializedName("cuisines")
    @Expose
    private final List<Cuisine> cuisines = null;

    public List<Cuisine> getCuisines() {
        return cuisines;
    }

}