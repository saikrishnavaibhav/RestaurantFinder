package hp.com.zom.geocode;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UserRating {

    @SerializedName("aggregate_rating")
    @Expose
    private String aggregateRating;
    @SerializedName("rating_text")
    @Expose
    private String ratingText;
    @SerializedName("rating_color")
    @Expose
    private String ratingColor;
    @SerializedName("votes")
    @Expose
    private String votes;
    @SerializedName("custom_rating_text")
    @Expose
    private String customRatingText;
    @SerializedName("custom_rating_text_background")
    @Expose
    private String customRatingTextBackground;
    @SerializedName("rating_tool_tip")
    @Expose
    private String ratingToolTip;

    public String getAggregateRating() {
        return aggregateRating;
    }

    public String getRatingText() {
        return ratingText;
    }

}