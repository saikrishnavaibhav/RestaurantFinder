package hp.com.zom;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.transition.Explode;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import hp.com.zom.cities.City;
import hp.com.zom.cities.LocationCitySuggestion;
import hp.com.zom.cuisine.Cuisine;
import hp.com.zom.cuisine.Cuisines;
import hp.com.zom.data.BaseUri;
import hp.com.zom.data.ServicePath;
import hp.com.zom.geocode.NearRestaurants;
import hp.com.zom.geocode.NearbyRestaurant;
import hp.com.zom.locations.LocationSuggesion;
import hp.com.zom.locations.Locations;
import hp.com.zom.restaurantdetails.RestaurantAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements MyReceiver.ConnectionListener {
    private ServicePath servicePath;
    private String cname;
    private SharedPreferences.Editor editor;
    public static Integer cityid;
    public static String latitude;
    public static String longitude;
    private List<LocationSuggesion> locationSuggesion;
    private List<Cuisine> cuisines1;
    private List<NearbyRestaurant> nearbyRestaurants;
    @BindView(R.id.cityname)
    public
    EditText cityname;
    @BindView(R.id.newlocation)
    public
    TextView newloc;
    @BindView(R.id.cuisinerecyclerview)
    public
    RecyclerView crv;
    @BindView(R.id.restaurantrecyclerview)
    public
    RecyclerView rrv;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkConnection();

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.PDmessage));
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMax(10);


        ButterKnife.bind(this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        crv.setLayoutManager(linearLayoutManager);
        crv.setHasFixedSize(true);

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            rrv.setLayoutManager(new GridLayoutManager(this, 2));
        } else
            rrv.setLayoutManager(new LinearLayoutManager(this));

        rrv.setHasFixedSize(true);

        servicePath = BaseUri.getRetrofit().create(ServicePath.class);


        if (savedInstanceState != null) {
            cuisines1 = savedInstanceState.getParcelableArrayList(getString(R.string.cuisines1));
            nearbyRestaurants = savedInstanceState.getParcelableArrayList(getString(R.string.nbr));
            cityid = savedInstanceState.getInt(getString(R.string.ci));
            String cn = savedInstanceState.getString(getString(R.string.citysi));
            if (cn != null) {
                cityname.setText(cn);
                cityname.setEnabled(false);
                cityname.setFocusable(false);
                newloc.setTextColor(Color.GREEN);
            }
            if (cuisines1 != null)
                crv.setAdapter(new CuisineAdapter(MainActivity.this, cuisines1));

            if (nearbyRestaurants != null)
                rrv.setAdapter(new RestaurantAdapter(MainActivity.this, nearbyRestaurants));

            progressDialog.cancel();
        } else {

            SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.cname), Context.MODE_PRIVATE);
            editor = sharedPreferences.edit();
            cname = sharedPreferences.getString(getString(R.string.cname), "");
            if (!cname.equals("")) {
                cityname.setText(cname);
                newloc.setTextColor(Color.GREEN);
                restaurants();
            }
        }
    }

    public void get(View view) {
        cname = cityname.getText().toString();
        if(cname.equals("")){
            Toast.makeText(this, getString(R.string.enter_location_search), Toast.LENGTH_SHORT).show();

        }else {
            newloc.setTextColor(Color.GREEN);
            editor.putString(getString(R.string.cname), cname);
            editor.apply();
            restaurants();
        }

    }

    private void restaurants() {
        progressDialog.show();
        progressDialog.setCancelable(false);

        try {
            retrofit2.Call<City> call2 = servicePath.getCities(BaseUri.q + cname);
            call2.enqueue(new Callback<City>() {
                @Override
                public void onResponse(@NonNull Call<City> call, @NonNull Response<City> response) {
                    assert response.body() != null;
                    List<LocationCitySuggestion> city = response.body().getLocationCitySuggestions();
                    try {
                        cityid = city.get(0).getId();
                        cityname.setEnabled(false);
                        cityname.setFocusable(false);
                        getcuisines(cityid);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, R.string.incorrectcn, Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onFailure(@NonNull Call<City> call, @NonNull Throwable t) {

                }
            });

            Call<Locations> locationsCall = servicePath.getLocations(BaseUri.locations + cityname.getText().toString().trim());
            locationsCall.enqueue(new Callback<Locations>() {
                @Override
                public void onResponse(@NonNull Call<Locations> call, @NonNull Response<Locations> response) {
                    Locations locations = response.body();
                    assert locations != null;
                    locationSuggesion = locations.getLocationSuggestions();
                    try {
                        longitude = String.valueOf(locationSuggesion.get(0).getLongitude());
                        latitude = String.valueOf(locationSuggesion.get(0).getLatitude());
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, R.string.locerror, Toast.LENGTH_SHORT).show();
                    }
                    res(latitude, longitude);
                }

                @Override
                public void onFailure(@NonNull Call<Locations> call, @NonNull Throwable t) {

                }
            });

        } catch (Exception ignored) {

        }
    }

    private void getcuisines(Integer cityid) {
        Call<Cuisines> cuisinesCall = servicePath.getCuisines(BaseUri.cuisines + cityid);
        cuisinesCall.enqueue(new Callback<Cuisines>() {
            @Override
            public void onResponse(@NonNull Call<Cuisines> call, @NonNull Response<Cuisines> response) {
                Cuisines cuisines = response.body();
                assert cuisines != null;
                cuisines1 = cuisines.getCuisines();
                crv.setAdapter(new CuisineAdapter(MainActivity.this, cuisines1));
            }

            @Override
            public void onFailure(@NonNull Call<Cuisines> call, @NonNull Throwable t) {

            }
        });
    }

    private void res(String latitude, String longitude) {
        Call<NearRestaurants> call = servicePath.getGeocode(BaseUri.geocode + getString(R.string.la) + latitude + getString(R.string.lo) + longitude);
        call.enqueue(new Callback<NearRestaurants>() {
            @Override
            public void onResponse(@NonNull Call<NearRestaurants> call, @NonNull Response<NearRestaurants> response) {
                assert response.body() != null;
                progressDialog.cancel();
                nearbyRestaurants = response.body().getNearbyRestaurants();
                rrv.setAdapter(new RestaurantAdapter(MainActivity.this, nearbyRestaurants));
            }

            @Override
            public void onFailure(@NonNull Call<NearRestaurants> call, @NonNull Throwable t) {

            }
        });
    }

    public void editlocation(View view) {
        cityname.setEnabled(true);
        cityname.setFocusableInTouchMode(true);
        newloc.setTextColor(Color.BLACK);
        editor.clear();
        editor.commit();
    }

    public void favs(View view) {
        startActivity(new Intent(MainActivity.this, FavouriteRestaurants.class));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(getString(R.string.nbr), (ArrayList<? extends Parcelable>) nearbyRestaurants);
        outState.putParcelableArrayList(getString(R.string.cuisines1), (ArrayList<? extends Parcelable>) cuisines1);
        outState.putString(getString(R.string.citysi), cityname.getText().toString());
        outState.putInt(getString(R.string.ci), cityid);
    }

    private void checkConnection() {
        boolean conn = MyReceiver.isConnected();
        snack(conn);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ConnectTest.getInstance().setConnectionListener(this);
    }

    @Override
    public void NetworkChanged(boolean conn) {
        snack(conn);
    }

    private void snack(boolean conn) {
        if (conn)
            Snackbar.make(findViewById(R.id.colay), R.string.online, Snackbar.LENGTH_SHORT).show();
        else
            Snackbar.make(findViewById(R.id.colay), R.string.connecttiinternet, Snackbar.LENGTH_SHORT).show();

    }

}
