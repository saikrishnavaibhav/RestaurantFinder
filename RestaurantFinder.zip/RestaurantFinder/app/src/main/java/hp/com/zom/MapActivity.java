package hp.com.zom;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Objects;

import hp.com.zom.restaurantdetails.RestaurantActivity;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private LatLng placeLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        CoordinatorLayout coordinatorLayout = findViewById(R.id.mapcolay);
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        placeLocation = RestaurantActivity.placeLocation;
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (Objects.requireNonNull(connectivityManager).getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {

            mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);


        } else if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.DISCONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.DISCONNECTED) {
            Snackbar.make(coordinatorLayout, R.string.nonetwork, Snackbar.LENGTH_LONG).show();
        }


    }

    @Override
    public void onMapReady(GoogleMap googlemap) {
        googlemap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        try {
            googlemap.setMyLocationEnabled(true);
        } catch (SecurityException ignored) {

        }

        googlemap.setTrafficEnabled(true);
        googlemap.setIndoorEnabled(true);
        googlemap.setBuildingsEnabled(true);
        googlemap.getUiSettings().setZoomControlsEnabled(true);
        //

        try {

            googlemap.addMarker(new MarkerOptions().position(placeLocation)
                    .title(RestaurantActivity.markername));
            googlemap.moveCamera(CameraUpdateFactory.newLatLng(placeLocation));
            googlemap.animateCamera(CameraUpdateFactory.zoomTo(15), 1000, null);
        } catch (Exception e) {

        }
    }
}
