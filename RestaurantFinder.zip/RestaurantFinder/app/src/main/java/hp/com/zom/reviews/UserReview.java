package hp.com.zom.reviews;

 import android.os.Parcel;
 import android.os.Parcelable;

 import com.google.gson.annotations.Expose;
 import com.google.gson.annotations.SerializedName;

 import hp.com.zom.reviews.Review;

 public class UserReview implements Parcelable {

    @SerializedName("review")
    @Expose
    private Review review;

     private UserReview(Parcel in) {
     }

     public static final Creator<UserReview> CREATOR = new Creator<UserReview>() {
         @Override
         public UserReview createFromParcel(Parcel in) {
             return new UserReview(in);
         }

         @Override
         public UserReview[] newArray(int size) {
             return new UserReview[size];
         }
     };

     public Review getReview() {
        return review;
    }

     @Override
     public int describeContents() {
         return 0;
     }

     @Override
     public void writeToParcel(Parcel dest, int flags) {
     }
 }