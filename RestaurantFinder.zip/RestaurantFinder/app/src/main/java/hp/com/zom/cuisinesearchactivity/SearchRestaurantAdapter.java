package hp.com.zom.cuisinesearchactivity;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import hp.com.zom.R;
import hp.com.zom.restaurantdetails.RestaurantActivity;
import hp.com.zom.searchentity.Restaurant;
import hp.com.zom.searchentity.Restaurant_;


public class SearchRestaurantAdapter extends RecyclerView.Adapter<SearchRestaurantAdapter.Viewholder> {
    public static List<Restaurant> restaurants;
    private final Context context;

    SearchRestaurantAdapter(EntitySearchActivity entitySearchActivity, List<Restaurant> restaurant) {
        restaurants = restaurant;
        this.context = entitySearchActivity;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new SearchRestaurantAdapter.Viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final Viewholder holder, int position) {
        final Restaurant_ restaurant = restaurants.get(position).getRestaurant();
        holder.textView.setText(restaurant.getName());

        Glide.with(context).load(restaurant.getFeaturedImage()).placeholder(R.drawable.ph)
                .error(R.drawable.ph).into(holder.imageView);
        final Intent intent = new Intent(context, RestaurantActivity.class);
        intent.putExtra(context.getString(R.string.porpor), position);
        intent.putExtra(context.getString(R.string.n), context.getString(R.string.nnn));
        intent.putExtra(context.getString(R.string.id), restaurant.getId());
        holder.res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return restaurants.size();
    }

    class Viewholder extends RecyclerView.ViewHolder {
        final TextView textView;
        final ImageView imageView;
        final LinearLayout res;

        Viewholder(View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.resname);
            imageView = itemView.findViewById(R.id.resimage);
            res = itemView.findViewById(R.id.res);
        }
    }
}
