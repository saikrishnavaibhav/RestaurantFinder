package hp.com.zom.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.AppWidgetTarget;

import java.util.Objects;

import hp.com.zom.MainActivity;
import hp.com.zom.R;


public class ZomWidget extends AppWidgetProvider {

    private static String rn;
    private static String ra;
    private static String ri;

    private static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                        int appWidgetId) {

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.zom_widget);
        AppWidgetTarget appWidgetTarget = new AppWidgetTarget(context, views, R.id.RI, appWidgetId);
        views.setTextViewText(R.id.RN, rn);
        views.setTextViewText(R.id.RA, ra);
        try {
            Glide.with(context).load(ri).asBitmap()
                    .override(480, 342).placeholder(R.drawable.ph).into(appWidgetTarget);
        } catch (Exception e) {
            Glide.with(context).load(R.drawable.ph).asBitmap().placeholder(R.drawable.ph).error(R.drawable.ph).into(appWidgetTarget);
        }

        Intent configIntent = new Intent(context, MainActivity.class);
        PendingIntent configPendingIntent = PendingIntent.getActivity(context, 0, configIntent, 0);
        views.setOnClickPendingIntent(R.id.RN, configPendingIntent);
        views.setOnClickPendingIntent(R.id.RA, configPendingIntent);
        views.setOnClickPendingIntent(R.id.RI, configPendingIntent);
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of


        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        if (Objects.equals(intent.getAction(), context.getString(R.string.widgetpackage))) {
            rn = intent.getStringExtra(context.getString(R.string.rn));
            ra = intent.getStringExtra(context.getString(R.string.ra));
            ri = intent.getStringExtra(context.getString(R.string.ri));

            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            int[] AppWidgetIds = appWidgetManager.getAppWidgetIds(new ComponentName(context, ZomWidget.class));
            ZomWidget.updateAppWidgets(context, appWidgetManager, AppWidgetIds);
        }

    }

    private static void updateAppWidgets(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appwidgetid : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appwidgetid);
        }

    }
}

