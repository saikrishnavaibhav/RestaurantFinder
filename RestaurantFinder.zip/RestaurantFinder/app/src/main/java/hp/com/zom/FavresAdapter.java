package hp.com.zom;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import hp.com.zom.restaurantdetails.RestaurantActivity;
import hp.com.zom.roomdatabase.Resdata;
import spencerstudios.com.bungeelib.Bungee;

public class FavresAdapter extends RecyclerView.Adapter<FavresAdapter.Viewholder> {
    private static List<Resdata> resdata;
    private final Context context;

    FavresAdapter(FavouriteRestaurants favouriteRestaurants, List<Resdata> resdata) {
        this.context = favouriteRestaurants;
        FavresAdapter.resdata = resdata;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new FavresAdapter.Viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final Viewholder holder, final int position) {
        final Resdata resdat = resdata.get(holder.getAdapterPosition());
        holder.textView.setText(resdat.getResname());
        Glide.with(context).load(resdat.getImage()).placeholder(R.drawable.ph).into(holder.imageView);
        holder.res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, RestaurantActivity.class);
                intent.putExtra(context.getString(R.string.n), context.getString(R.string.ffff));
                intent.putExtra(context.getString(R.string.id), resdat.getId());
                context.startActivity(intent);
                Bungee.slideLeft(context);
            }
        });
    }

    @Override
    public int getItemCount() {
        return resdata.size();
    }

    class Viewholder extends RecyclerView.ViewHolder {
        final TextView textView;
        final ImageView imageView;
        final LinearLayout res;

        Viewholder(View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.resname);
            imageView = itemView.findViewById(R.id.resimage);
            res = itemView.findViewById(R.id.res);
        }
    }
}
