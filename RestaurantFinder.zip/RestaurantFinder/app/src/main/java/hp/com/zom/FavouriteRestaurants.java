package hp.com.zom;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import hp.com.zom.roomdatabase.Resdata;
import hp.com.zom.roomdatabase.ViewModel;


public class FavouriteRestaurants extends AppCompatActivity {
    @BindView(R.id.favresrecycler)
    public RecyclerView frr;
    @BindView(R.id.mark)
    public
    ImageView mark;
    @BindView(R.id.favorit)
    public
    TextView fav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite_restaurants);

        ButterKnife.bind(this);

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            frr.setLayoutManager(new GridLayoutManager(this, 2));
        } else
            frr.setLayoutManager(new LinearLayoutManager(this));
        frr.setHasFixedSize(true);
        assign();

    }

    private void assign() {
        ViewModel viewModel = ViewModelProviders.of(this).get(ViewModel.class);
        viewModel.getRestaurant().observe(this, new Observer<List<Resdata>>() {
            @Override
            public void onChanged(@Nullable List<Resdata> resdata) {
                assert resdata != null;
                if (resdata.size() > 0) {
                    frr.setVisibility(View.VISIBLE);
                    frr.setAdapter(new FavresAdapter(FavouriteRestaurants.this, resdata));
                    mark.setVisibility(View.GONE);
                    fav.setVisibility(View.GONE);
                } else {
                    frr.setVisibility(View.GONE);
                    mark.setVisibility(View.VISIBLE);
                    fav.setVisibility(View.VISIBLE);

                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return true;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        assign();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
