package hp.com.zom.restaurantdetails;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import hp.com.zom.R;
import hp.com.zom.reviews.Review;
import hp.com.zom.reviews.User;
import hp.com.zom.reviews.UserReview;

public class UserRatingsAdapter extends RecyclerView.Adapter<UserRatingsAdapter.Viewholder> {
    private final List<UserReview> revies;
    private final Context context;

    UserRatingsAdapter(RestaurantActivity restaurantActivity, List<UserReview> revie) {
        this.context = restaurantActivity;
        this.revies = revie;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.review, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        UserReview review = revies.get(position);
        Review review1 = review.getReview();
        User user = review1.getUser();
        holder.user.setText(user.getName());
        holder.review.setText(review1.getReviewText());
        Glide.with(context).load(user.getProfileImage()).into(holder.ig);
        String set = context.getString(R.string.rated) + String.valueOf(review1.getRating());
        holder.rated.setText(set);

    }

    @Override
    public int getItemCount() {
        return revies.size();
    }

    class Viewholder extends RecyclerView.ViewHolder {
        final TextView user;
        final TextView review;
        final TextView rated;
        final ImageView ig;

        Viewholder(View itemView) {
            super(itemView);
            user = itemView.findViewById(R.id.author);
            review = itemView.findViewById(R.id.review);
            rated = itemView.findViewById(R.id.rated);
            ig = itemView.findViewById(R.id.revimg);
        }
    }
}
