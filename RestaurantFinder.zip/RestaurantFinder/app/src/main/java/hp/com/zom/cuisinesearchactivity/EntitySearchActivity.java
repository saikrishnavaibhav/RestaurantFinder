package hp.com.zom.cuisinesearchactivity;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import hp.com.zom.CuisineAdapter;
import hp.com.zom.FavouriteRestaurants;
import hp.com.zom.MainActivity;
import hp.com.zom.R;
import hp.com.zom.cuisine.Cuisine;
import hp.com.zom.cuisine.Cuisines;
import hp.com.zom.data.BaseUri;
import hp.com.zom.data.ServicePath;
import hp.com.zom.searchentity.Restaurant;
import hp.com.zom.searchentity.Searchentitymain;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import spencerstudios.com.bungeelib.Bungee;

public class EntitySearchActivity extends AppCompatActivity implements CuisineseearchAdapter.Entities {
    private List<Cuisine> cuisines1, cuisines2;
    public List<Restaurant> restaurant;
    @BindView(R.id.cuisinerecyclerview)
    public RecyclerView crv;
    @BindView(R.id.cuisinerestaurantrecyclerview)
    public RecyclerView crrv;
    public static int pos;
    @BindView(R.id.adView)
    public AdView adView;
    ProgressDialog progressDialog;
    ServicePath servicePath;
    String entity = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entity_search);

        ButterKnife.bind(this);

        //progress Dialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.PDmessage));
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMax(10);
        progressDialog.show();
        progressDialog.setCancelable(false);


        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);

        crv.setLayoutManager(linearLayoutManager);
        crv.setHasFixedSize(true);

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            crrv.setLayoutManager(new GridLayoutManager(this, 2));
        } else
            crrv.setLayoutManager(new LinearLayoutManager(this));

        crrv.setHasFixedSize(true);


        Bundle b = getIntent().getExtras();

        assert b != null;
        if (b.getString(getString(R.string.caca)) != null) {
            entity = BaseUri.search + getString(R.string.entity_id) + MainActivity.cityid + getString(R.string.lat) + MainActivity.latitude + getString(R.string.lon) + MainActivity.longitude + getString(R.string.cuisi) + CuisineAdapter.id;
        } else if (Objects.equals(b.getString(getString(R.string.csa)), getString(R.string.csa))) {
            entity = BaseUri.search + getString(R.string.entity_id) + MainActivity.cityid + getString(R.string.lat) + MainActivity.latitude + getString(R.string.lon) + MainActivity.longitude + getString(R.string.cuisi) + CuisineseearchAdapter.id;
        }

        pos = b.getInt(getString(R.string.pos));

        servicePath = BaseUri.getRetrofit().create(ServicePath.class);

        if (savedInstanceState != null) {
            cuisines1 = savedInstanceState.getParcelableArrayList(getString(R.string.cui));
            restaurant = savedInstanceState.getParcelableArrayList(getString(R.string.res));
            crv.setAdapter(new CuisineseearchAdapter(EntitySearchActivity.this, cuisines1, this));
            crrv.setAdapter(new SearchRestaurantAdapter(EntitySearchActivity.this, restaurant));
            progressDialog.cancel();
        } else {

            Call<Cuisines> cuisinesCall = servicePath.getCuisines(BaseUri.cuisines + MainActivity.cityid);
            cuisinesCall.enqueue(new Callback<Cuisines>() {
                @Override
                public void onResponse(@NonNull Call<Cuisines> call, @NonNull Response<Cuisines> response) {
                    Cuisines cuisines = response.body();
                    assert cuisines != null;
                    progressDialog.cancel();
                    cuisines1 = cuisines.getCuisines();
                    cuisines2 = cuisines.getCuisines();
                    crv.setAdapter(new CuisineseearchAdapter(EntitySearchActivity.this, cuisines1, EntitySearchActivity.this));
                    crv.scrollToPosition(pos);

                }
                @Override
                public void onFailure(@NonNull Call<Cuisines> call, @NonNull Throwable t) {
                }
            });
            retrofit2.Call<Searchentitymain> searchentitymainCall = servicePath.getCuisineSearch(entity);
            searchentitymainCall.enqueue(new Callback<Searchentitymain>() {
                @Override
                public void onResponse(@NonNull Call<Searchentitymain> call, @NonNull Response<Searchentitymain> response) {
                    Searchentitymain searchentitymain = response.body();
                    assert searchentitymain != null;
                    restaurant = searchentitymain.getRestaurants();
                    crrv.setAdapter(new SearchRestaurantAdapter(EntitySearchActivity.this, restaurant));
                }

                @Override
                public void onFailure(@NonNull Call<Searchentitymain> call, @NonNull Throwable t) {
                    progressDialog.cancel();
                    Toast.makeText(EntitySearchActivity.this, getString(R.string.failed), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(getString(R.string.cui), (ArrayList<? extends Parcelable>) cuisines1);
        outState.putParcelableArrayList(getString(R.string.res), (ArrayList<? extends Parcelable>) restaurant);
    }

    public void favs(View view) {
        startActivity(new Intent(EntitySearchActivity.this, FavouriteRestaurants.class));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

    @Override
    public void entitessesrch(int po) {
        pos = po;
        crv.setAdapter(new CuisineseearchAdapter(EntitySearchActivity.this, cuisines1, EntitySearchActivity.this));
        crv.scrollToPosition(po);

        progressDialog.show();
        entity = BaseUri.search + getString(R.string.entity_id) + MainActivity.cityid + getString(R.string.lat) + MainActivity.latitude + getString(R.string.lon) + MainActivity.longitude + getString(R.string.cuisi) + CuisineseearchAdapter.id;
        retrofit2.Call<Searchentitymain> searchentitymainCall = servicePath.getCuisineSearch(entity);
        searchentitymainCall.enqueue(new Callback<Searchentitymain>() {
            @Override
            public void onResponse(@NonNull Call<Searchentitymain> call, @NonNull Response<Searchentitymain> response) {
                Searchentitymain searchentitymain = response.body();
                assert searchentitymain != null;
                if (restaurant != null) {
                    restaurant.clear();
                }
                restaurant = searchentitymain.getRestaurants();
                progressDialog.cancel();
                crrv.setAdapter(new SearchRestaurantAdapter(EntitySearchActivity.this, restaurant));
            }

            @Override
            public void onFailure(@NonNull Call<Searchentitymain> call, @NonNull Throwable t) {
                progressDialog.cancel();
                Toast.makeText(EntitySearchActivity.this, getString(R.string.failed), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
