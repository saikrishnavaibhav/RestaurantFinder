package hp.com.zom.roomdatabase;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {Resdata.class}, version = 6, exportSchema = false)
public abstract class DataBase extends RoomDatabase {
    private static final String DATABASE_NAME = "favrestaurant.db";
    private static DataBase sInstance;
    private static final Object LOCK = new Object();

    public static DataBase getInstance(Context context) {
        if (sInstance == null) {
            synchronized (LOCK) {
                sInstance = Room.databaseBuilder(context.getApplicationContext(),
                        DataBase.class, DataBase.DATABASE_NAME)
                        .allowMainThreadQueries()
                        .fallbackToDestructiveMigration()
                        .build();
            }
        }
        return sInstance;
    }

    public abstract Daoaccess daoaccess();
}
