package hp.com.zom.geocode;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Location_ implements Parcelable{

    @SerializedName("address")
    @Expose
    private final String address;
    @SerializedName("locality")
    @Expose
    private final String locality;
    @SerializedName("city")
    @Expose
    private final String city;
    @SerializedName("city_id")
    @Expose
    private final Integer cityId;
    @SerializedName("latitude")
    @Expose
    private final String latitude;
    @SerializedName("longitude")
    @Expose
    private final String longitude;
    @SerializedName("zipcode")
    @Expose
    private final String zipcode;
    @SerializedName("country_id")
    @Expose
    private final Integer countryId;
    @SerializedName("locality_verbose")
    @Expose
    private final String localityVerbose;

    private Location_(Parcel in) {
        address = in.readString();
        locality = in.readString();
        city = in.readString();
        if (in.readByte() == 0) {
            cityId = null;
        } else {
            cityId = in.readInt();
        }
        latitude = in.readString();
        longitude = in.readString();
        zipcode = in.readString();
        if (in.readByte() == 0) {
            countryId = null;
        } else {
            countryId = in.readInt();
        }
        localityVerbose = in.readString();
    }

    public static final Creator<Location_> CREATOR = new Creator<Location_>() {
        @Override
        public Location_ createFromParcel(Parcel in) {
            return new Location_(in);
        }

        @Override
        public Location_[] newArray(int size) {
            return new Location_[size];
        }
    };

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(address);
        dest.writeString(locality);
        dest.writeString(city);
        if (cityId == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(cityId);
        }
        dest.writeString(latitude);
        dest.writeString(longitude);
        dest.writeString(zipcode);
        if (countryId == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(countryId);
        }
        dest.writeString(localityVerbose);
    }
}