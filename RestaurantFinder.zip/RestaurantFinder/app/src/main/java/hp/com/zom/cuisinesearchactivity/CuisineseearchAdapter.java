package hp.com.zom.cuisinesearchactivity;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import hp.com.zom.R;
import hp.com.zom.cuisine.Cuisine;
import hp.com.zom.cuisine.Cuisine_;

public class CuisineseearchAdapter extends RecyclerView.Adapter<CuisineseearchAdapter.Viewholder> {
    private final Context context;
    private final List<Cuisine> cuisines;
    public static int id;
    Entities entities;

    public interface Entities {
        void entitessesrch(int po);
    }

    CuisineseearchAdapter(EntitySearchActivity entitySearchActivity, List<Cuisine> cuisines1, EntitySearchActivity searchActivity) {
        this.context = entitySearchActivity;
        this.cuisines = cuisines1;
        this.entities=searchActivity;
    }

    @NonNull
    @Override
    public CuisineseearchAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CuisineseearchAdapter.Viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.cuisine, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final CuisineseearchAdapter.Viewholder holder, final int position) {
        final Cuisine_ cuisine_ = cuisines.get(holder.getAdapterPosition()).getCuisine();
        holder.textView.setText(cuisine_.getCuisineName());
        id = cuisine_.getCuisineId();
        if (EntitySearchActivity.pos == holder.getAdapterPosition()) {
            holder.textView.setBackgroundColor(Color.RED);
            holder.textView.setTextColor(Color.WHITE);
            holder.cardView.setCardElevation(100);
            holder.cardView.setFocusable(true);
        } else {
            holder.textView.setBackgroundColor(Color.DKGRAY);
            holder.textView.setTextColor(Color.WHITE);
        }

        holder.textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               entities.entitessesrch(holder.getAdapterPosition());

               /* Intent intent = new Intent(context, EntitySearchActivity.class);
                intent.putExtra(context.getString(R.string.csa), context.getString(R.string.csa));
                intent.putExtra(context.getString(R.string.pos), holder.getAdapterPosition());
                context.startActivity(intent);*/

            }
        });

    }

    @Override
    public int getItemCount() {
        return cuisines.size();
    }

    class Viewholder extends RecyclerView.ViewHolder {
        final TextView textView;
        final CardView cardView;

        Viewholder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.cuisinet);
            cardView = itemView.findViewById(R.id.card);

        }
    }
}
