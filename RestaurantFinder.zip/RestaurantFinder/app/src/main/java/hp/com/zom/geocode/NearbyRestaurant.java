
package hp.com.zom.geocode;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NearbyRestaurant implements Parcelable {

    @SerializedName("restaurant")
    @Expose
    private final Restaurant restaurant;

    private NearbyRestaurant(Parcel in) {
        restaurant = in.readParcelable(Restaurant.class.getClassLoader());
    }

    public static final Creator<NearbyRestaurant> CREATOR = new Creator<NearbyRestaurant>() {
        @Override
        public NearbyRestaurant createFromParcel(Parcel in) {
            return new NearbyRestaurant(in);
        }

        @Override
        public NearbyRestaurant[] newArray(int size) {
            return new NearbyRestaurant[size];
        }
    };

    public Restaurant getRestaurant() {
        return restaurant;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(restaurant, flags);
    }
}