package hp.com.zom.roomdatabase;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

public class ViewModel extends AndroidViewModel {
    private final LiveData<List<Resdata>> restaurant;

    public ViewModel(@NonNull Application application) {
        super(application);
        DataBase dataBase = DataBase.getInstance(this.getApplication());
        restaurant = dataBase.daoaccess().fetchresdata();

    }

    public LiveData<List<Resdata>> getRestaurant() {
        return restaurant;
    }
}
