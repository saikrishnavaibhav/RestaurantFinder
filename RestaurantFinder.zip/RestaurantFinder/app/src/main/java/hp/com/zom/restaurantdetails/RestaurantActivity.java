package hp.com.zom.restaurantdetails;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Build;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.support.v7.widget.Toolbar;
import android.transition.Explode;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import hp.com.zom.MapActivity;
import hp.com.zom.R;
import hp.com.zom.cuisinesearchactivity.SearchRestaurantAdapter;
import hp.com.zom.data.BaseUri;
import hp.com.zom.data.ServicePath;
import hp.com.zom.geocode.Location_;
import hp.com.zom.geocode.Restaurant;
import hp.com.zom.geocode.UserRating;
import hp.com.zom.reviews.Revie;
import hp.com.zom.reviews.UserReview;
import hp.com.zom.roomdatabase.DataBase;
import hp.com.zom.roomdatabase.Resdata;
import hp.com.zom.roomdatabase.ViewModel;
import hp.com.zom.searchentity.Location;
import hp.com.zom.searchentity.Restaurant_;
import hp.com.zom.widget.ZomIntentService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import spencerstudios.com.bungeelib.Bungee;

public class RestaurantActivity extends AppCompatActivity {
    @BindView(R.id.resimg)
    public
    ImageView resimg;
    @BindView(R.id.resname)
    public
    TextView resname;
    @BindView(R.id.resaddress)
    public
    TextView resaddress;
    @BindView(R.id.rescity)
    public
    TextView rescity;
    @BindView(R.id.avgcost)
    public
    TextView avgcost;
    @BindView(R.id.pricerange)
    public
    TextView pricerange;
    @BindView(R.id.ratingtext)
    public
    TextView ratingtext;
    @BindView(R.id.reviewmsg)
    public
    TextView rm;
    @BindView(R.id.reviews)
    public
    TextView reviewsavailable;
    @BindView(R.id.reviewrecycler)
    public
    RecyclerView urr;
    @BindView(R.id.rating)
    public
    TextView rating;
    @BindView(R.id.cuisinestext)
    public
    TextView cuisines;
    @BindView(R.id.linearrestarant)
    LinearLayout linearLayout;
    @BindView(R.id.fav)
    public
    TextView fav;
    private Bundle b;
    private DataBase dataBase;
    private Resdata resdata1;
    private boolean boo = false;
    private String id;
    private Double latitude;
    private Double longitude;
    public static LatLng placeLocation;
    public static String markername;
    private List<UserReview> revie;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        ButterKnife.bind(this);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        final CollapsingToolbarLayout collapsingToolbarLayout = findViewById(R.id.collapsebar);
        AppBarLayout appBarLayout = findViewById(R.id.appbar);
        collapsingToolbarLayout.setTitle("");
        appBarLayout.setExpanded(true);
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean show = false;
            int i = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (i == -1) {
                    i = appBarLayout.getTotalScrollRange();
                }
                if (i + verticalOffset == 0) {
                    collapsingToolbarLayout.setTitle(getString(R.string.detail));
                    show = true;
                } else if (show) {
                    collapsingToolbarLayout.setTitle("");
                    show = false;
                }

            }
        });


        resdata1 = new Resdata();
        b = getIntent().getExtras();
        assert b != null;
        id = b.getString(getString(R.string.id));
        check();
        dataBase = DataBase.getInstance(this);
        final Intent i = new Intent(RestaurantActivity.this, ZomIntentService.class);
        int po;
        if (Objects.equals(b.getString(getString(R.string.n)), getString(R.string.n)) || Objects.requireNonNull(b.getString(getString(R.string.n))).equals(getString(R.string.nnn))) {
            po = b.getInt(getString(R.string.porpor));

            if (getString(R.string.n).equals(b.getString(getString(R.string.n)))) {
                Restaurant restaurant = RestaurantAdapter.nearbyRestaurants.get(po).getRestaurant();
                Location_ location = restaurant.getLocation();
                UserRating userRating = restaurant.getUserRating();
                resname.setText(restaurant.getName());
                resaddress.setText(location.getAddress());
                rescity.setText(location.getCity());
                avgcost.setText(String.valueOf(restaurant.getAverageCostForTwo()));
                pricerange.setText(String.valueOf(restaurant.getPriceRange()));
                cuisines.setText(restaurant.getCuisines());
                Glide.with(getApplicationContext()).load(restaurant.getFeaturedImage()).thumbnail(0.1f).placeholder(R.drawable.ph).into(resimg);
                ratingtext.setText(userRating.getRatingText());
                rating.setText(userRating.getAggregateRating());

                //for widget
                i.putExtra(getString(R.string.ri), restaurant.getFeaturedImage());

                //into FAVdata class
                resdata1.setId(String.valueOf(restaurant.getR().getResId()));
                resdata1.setImage(restaurant.getFeaturedImage());
                resdata1.setLatitude(Double.parseDouble(restaurant.getLocation().getLatitude()));
                resdata1.setLongitude(Double.parseDouble(restaurant.getLocation().getLongitude()));

                //map
                latitude = Double.parseDouble(restaurant.getLocation().getLatitude());
                longitude = Double.parseDouble(restaurant.getLocation().getLongitude());
                placeLocation = new LatLng(latitude, longitude);


            } else if (Objects.requireNonNull(b.getString(getString(R.string.n))).equals(getString(R.string.nnn))) {
                Restaurant_ restaurant1 = SearchRestaurantAdapter.restaurants.get(po).getRestaurant();
                Location location = restaurant1.getLocation();
                hp.com.zom.searchentity.UserRating userRating = restaurant1.getUserRating();
                resname.setText(restaurant1.getName());
                resaddress.setText(location.getAddress());
                rescity.setText(location.getCity());
                avgcost.setText(String.valueOf(restaurant1.getAverageCostForTwo()));
                pricerange.setText(String.valueOf(restaurant1.getPriceRange()));
                cuisines.setText(restaurant1.getCuisines());
                Glide.with(getApplicationContext()).load(restaurant1.getFeaturedImage()).thumbnail(0.1f).placeholder(R.drawable.ph).into(resimg);
                ratingtext.setText(userRating.getRatingText());
                rating.setText(userRating.getAggregateRating());
                //for widget

                i.putExtra(getString(R.string.ri), restaurant1.getFeaturedImage());
                //into FAVdata class
                resdata1.setId(String.valueOf(restaurant1.getR().getResId()));
                resdata1.setImage(restaurant1.getFeaturedImage());
                resdata1.setLatitude(Double.parseDouble(restaurant1.getLocation().getLatitude()));
                resdata1.setLongitude(Double.parseDouble(restaurant1.getLocation().getLongitude()));


                //map
                latitude = Double.parseDouble(restaurant1.getLocation().getLatitude());
                longitude = Double.parseDouble(restaurant1.getLocation().getLongitude());

                placeLocation = new LatLng(latitude, longitude);

            }
        } else if (Objects.requireNonNull(b.getString(getString(R.string.n))).equals(getString(R.string.ffff))) {
            final Double[] lat = new Double[1];
            final Double[] lon = new Double[1];
            final Resdata[] resfavData = new Resdata[1];
            ViewModel viewModel = ViewModelProviders.of(this).get(ViewModel.class);
            viewModel.getRestaurant().observe(this, new Observer<List<Resdata>>() {
                @Override
                public void onChanged(@Nullable List<Resdata> redata) {
                    assert redata != null;
                    for (int m = 0; m < redata.size(); m++) {
                        if (id.equals(redata.get(m).getId())) {
                            resfavData[0] = redata.get(m);
                            resname.setText(resfavData[0].getResname());
                            resaddress.setText(resfavData[0].getResaddress());
                            rescity.setText(resfavData[0].getRescity());
                            avgcost.setText(resfavData[0].getAvgcost());
                            pricerange.setText(resfavData[0].getPrice());
                            Glide.with(getApplicationContext()).load(resfavData[0].getImage()).into(resimg);
                            i.putExtra(getString(R.string.ri), resfavData[0].getImage());
                            ratingtext.setText(resfavData[0].getRatingtext());
                            rating.setText(resfavData[0].getRating());
                            cuisines.setText(resfavData[0].getCuisines());

                            resdata1.setId(resfavData[0].getId());
                            resdata1.setImage(resfavData[0].getImage());
                            resdata1.setLongitude(resfavData[0].getLatitude());
                            resdata1.setLongitude(resfavData[0].getLongitude());

                            lat[0] = resfavData[0].getLatitude();
                            lon[0] = resfavData[0].getLongitude();

                            //map
                            latitude = lat[0];
                            longitude = lon[0];
                            markername = resname.getText().toString();
                            placeLocation = new LatLng(latitude, longitude);
                            i.putExtra(getString(R.string.rn), resname.getText().toString());
                            i.putExtra(getString(R.string.ra), resaddress.getText().toString());
                            startService(i);
                        }
                    }
                }
            });
        }

        i.putExtra(getString(R.string.rn), resname.getText().toString());
        i.putExtra(getString(R.string.ra), resaddress.getText().toString());
        startService(i);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        SnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(urr);
        urr.setLayoutManager(linearLayoutManager);

        markername = resname.getText().toString();

        if (savedInstanceState != null) {
            revie = savedInstanceState.getParcelableArrayList(getString(R.string.reviewparcel));
            urr.setAdapter(new UserRatingsAdapter(RestaurantActivity.this, revie));
        } else {
            String resid = getString(R.string.res_id);
            String res = resid + b.getString(getString(R.string.id));

            ServicePath servicePath = BaseUri.getRetrofit().create(ServicePath.class);
            final Call<Revie> revieCall = servicePath.getReviews(BaseUri.review + res);
            revieCall.enqueue(new Callback<Revie>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onResponse(@NonNull Call<Revie> call, @NonNull Response<Revie> response) {
                    assert response.body() != null;
                    revie = response.body().getUserReviews();
                    String rav = getString(R.string.rvavaliable) + revie.size();
                    if (revie != null) reviewsavailable.setText(rav);
                    UserRatingsAdapter userRatingsAdapter = new UserRatingsAdapter(RestaurantActivity.this, revie);
                    urr.setAdapter(userRatingsAdapter);
                }

                @Override
                public void onFailure(@NonNull Call<Revie> call, @NonNull Throwable t) {
                    rm.setVisibility(View.VISIBLE);
                }
            });
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                Bungee.slideRight(this);
                break;
        }
        return true;
    }

    public void FAV(View view) {
        resdata1.setResname(resname.getText().toString());
        resdata1.setResaddress(resaddress.getText().toString());
        resdata1.setAvgcost(avgcost.getText().toString());
        resdata1.setRescity(rescity.getText().toString());
        resdata1.setRating(rating.getText().toString());
        resdata1.setRatingtext(ratingtext.getText().toString());
        resdata1.setPrice(pricerange.getText().toString());
        resdata1.setCuisines(cuisines.getText().toString());

        Resdata resdata = resdata1;

        if (boo) {
            boo = false;
            fav.setBackgroundResource(R.drawable.notfav);
            if (Objects.requireNonNull(b.getString(getString(R.string.n))).equals(getString(R.string.ffff))) {
                dataBase.daoaccess().deleteres(resdata);
                Toast.makeText(this, R.string.delfav, Toast.LENGTH_SHORT).show();
                finish();
            } else {
                dataBase.daoaccess().deleteres(resdata);
                Toast.makeText(this, R.string.delfav, Toast.LENGTH_SHORT).show();
            }

        } else {
            boo = true;
            fav.setBackgroundResource(R.drawable.fav);
            dataBase.daoaccess().insertres(resdata);
            Toast.makeText(this, R.string.addFav, Toast.LENGTH_SHORT).show();
        }
    }

    private void check() {

        ViewModel viewModel = ViewModelProviders.of(this).get(ViewModel.class);
        viewModel.getRestaurant().observe(this, new Observer<List<Resdata>>() {
            @Override
            public void onChanged(@Nullable List<Resdata> resdata) {
                for (int m = 0; m < Objects.requireNonNull(resdata).size(); m++) {
                    Resdata favData = resdata.get(m);
                    String s = favData.getId();
                    if (s.equals(id)) {
                        fav.setBackgroundResource(R.drawable.fav);
                        boo = true;
                        return;
                    } else {
                        fav.setBackgroundResource(R.drawable.notfav);
                        boo = false;
                    }
                }
            }
        });
    }


    public void Maps(View view) {
        startActivity(new Intent(RestaurantActivity.this, MapActivity.class));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(getString(R.string.reviewparcel), (ArrayList<? extends Parcelable>) revie);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Bungee.slideRight(this);
    }
}


