package hp.com.zom;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import hp.com.zom.cuisine.Cuisine;
import hp.com.zom.cuisine.Cuisine_;
import hp.com.zom.cuisinesearchactivity.EntitySearchActivity;

public class CuisineAdapter extends RecyclerView.Adapter<CuisineAdapter.Viewholder> {
    private final Context context;
    private final List<Cuisine> cuisines;
    public static int id;

    CuisineAdapter(MainActivity ma, List<Cuisine> cuisines) {
        this.context = ma;
        this.cuisines = cuisines;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.cuisine, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final Viewholder holder, final int position) {

        final Cuisine_ cuisine_ = cuisines.get(holder.getAdapterPosition()).getCuisine();
        holder.textView.setText(cuisine_.getCuisineName());
        holder.textView.setBackgroundColor(Color.DKGRAY);
        holder.textView.setTextColor(Color.WHITE);
        holder.textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EntitySearchActivity.class);
                id = cuisine_.getCuisineId();
                intent.putExtra(context.getString(R.string.caca), context.getString(R.string.caca));
                intent.putExtra(context.getString(R.string.pos), holder.getAdapterPosition());
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        if (cuisines != null)
            return cuisines.size();
        else
            return 0;
    }

    class Viewholder extends RecyclerView.ViewHolder {
        final TextView textView;

        Viewholder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.cuisinet);

        }
    }
}
