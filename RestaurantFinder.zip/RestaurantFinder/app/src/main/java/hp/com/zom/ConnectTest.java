package hp.com.zom;

import android.app.Application;

public class ConnectTest extends Application {
    private static ConnectTest mInstance;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
    }

    public static synchronized ConnectTest getInstance() {
        return mInstance;
    }

    public void setConnectionListener(MyReceiver.ConnectionListener listener) {
        MyReceiver.connectionListener = listener;
    }
}
