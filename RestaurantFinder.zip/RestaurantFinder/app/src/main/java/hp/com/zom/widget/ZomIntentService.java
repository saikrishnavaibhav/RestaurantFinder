package hp.com.zom.widget;

import android.app.IntentService;
import android.content.Intent;

import hp.com.zom.R;


public class ZomIntentService extends IntentService {
    public ZomIntentService() {
        super("ZomIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            Intent i = new Intent(ZomIntentService.this, ZomWidget.class);
            i.putExtra(getString(R.string.rn), intent.getStringExtra(getString(R.string.rn)));
            i.putExtra(getString(R.string.ra), intent.getStringExtra(getString(R.string.ra)));
            i.putExtra(getString(R.string.ri), intent.getStringExtra(getString(R.string.ri)));
            i.setAction(getString(R.string.widgetpackage));
            sendBroadcast(i);
        }
    }

}
