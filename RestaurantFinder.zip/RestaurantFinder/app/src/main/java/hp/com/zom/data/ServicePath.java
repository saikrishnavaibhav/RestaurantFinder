package hp.com.zom.data;


import hp.com.zom.BuildConfig;
import hp.com.zom.cities.City;
import hp.com.zom.cuisine.Cuisines;
import hp.com.zom.geocode.NearRestaurants;
import hp.com.zom.locations.Locations;
import hp.com.zom.reviews.Revie;
import hp.com.zom.searchentity.Searchentitymain;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Url;

public interface ServicePath {

    @Headers(BuildConfig.ZomatoKey)
    @GET
    Call<City> getCities(@Url String url);

    @Headers(BuildConfig.ZomatoKey)
    @GET
    Call<NearRestaurants> getGeocode(@Url String url);

    @Headers(BuildConfig.ZomatoKey)
    @GET
    Call<Revie> getReviews(@Url String url);

    @Headers(BuildConfig.ZomatoKey)
    @GET
    Call<Locations> getLocations(@Url String url);

    @Headers(BuildConfig.ZomatoKey)
    @GET
    Call<Cuisines> getCuisines(@Url String url);

    @Headers(BuildConfig.ZomatoKey)
    @GET
    Call<Searchentitymain> getCuisineSearch(@Url String url);
}
