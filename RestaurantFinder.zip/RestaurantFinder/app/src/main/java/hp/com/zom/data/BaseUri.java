package hp.com.zom.data;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BaseUri {
    private static final String URL = "https://developers.zomato.com/api/v2.1/";
    public static final String q = "cities?q=";
    public static final String geocode = "geocode?";
    public static final String review = "reviews?";
    public static final String locations = "locations?query=";
    public static final String cuisines = "cuisines?city_id=";
    public static final String search = "search?";
    private static Retrofit retrofit;

    public static Retrofit getRetrofit() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

        }
        return retrofit;
    }


}
