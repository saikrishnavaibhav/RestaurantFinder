package hp.com.zom.geocode;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import hp.com.zom.geocode.Location_;

public class Restaurant implements Parcelable {

    @SerializedName("R")
    @Expose
    private Re r;
    @SerializedName("apikey")
    @Expose
    private final String apikey;
    @SerializedName("id")
    @Expose
    private final String id;
    @SerializedName("name")
    @Expose
    private final String name;
    @SerializedName("url")
    @Expose
    private final String url;
    @SerializedName("location")
    @Expose
    private Location_ location;
    @SerializedName("switch_to_order_menu")
    @Expose
    private final Integer switchToOrderMenu;
    @SerializedName("cuisines")
    @Expose
    private final String cuisines;
    @SerializedName("average_cost_for_two")
    @Expose
    private final Integer averageCostForTwo;
    @SerializedName("price_range")
    @Expose
    private final Integer priceRange;
    @SerializedName("currency")
    @Expose
    private final String currency;
    @SerializedName("offers")
    @Expose
    private List<Object> offers = null;
    @SerializedName("opentable_support")
    @Expose
    private final Integer opentableSupport;
    @SerializedName("is_zomato_book_res")
    @Expose
    private final Integer isZomatoBookRes;
    @SerializedName("mezzo_provider")
    @Expose
    private final String mezzoProvider;
    @SerializedName("is_book_form_web_view")
    @Expose
    private final Integer isBookFormWebView;
    @SerializedName("book_form_web_view_url")
    @Expose
    private final String bookFormWebViewUrl;
    @SerializedName("book_again_url")
    @Expose
    private final String bookAgainUrl;
    @SerializedName("thumb")
    @Expose
    private final String thumb;
    @SerializedName("user_rating")
    @Expose
    private UserRating userRating;
    @SerializedName("photos_url")
    @Expose
    private final String photosUrl;
    @SerializedName("menu_url")
    @Expose
    private final String menuUrl;
    @SerializedName("featured_image")
    @Expose
    private final String featuredImage;
    @SerializedName("has_online_delivery")
    @Expose
    private final Integer hasOnlineDelivery;
    @SerializedName("is_delivering_now")
    @Expose
    private final Integer isDeliveringNow;
    @SerializedName("include_bogo_offers")
    @Expose
    private final Boolean includeBogoOffers;
    @SerializedName("deeplink")
    @Expose
    private final String deeplink;
    @SerializedName("is_table_reservation_supported")
    @Expose
    private final Integer isTableReservationSupported;
    @SerializedName("has_table_booking")
    @Expose
    private final Integer hasTableBooking;
    @SerializedName("events_url")
    @Expose
    private final String eventsUrl;

    Restaurant(Parcel in) {
        apikey = in.readString();
        id = in.readString();
        name = in.readString();
        url = in.readString();
        if (in.readByte() == 0) {
            switchToOrderMenu = null;
        } else {
            switchToOrderMenu = in.readInt();
        }
        cuisines = in.readString();
        if (in.readByte() == 0) {
            averageCostForTwo = null;
        } else {
            averageCostForTwo = in.readInt();
        }
        if (in.readByte() == 0) {
            priceRange = null;
        } else {
            priceRange = in.readInt();
        }
        currency = in.readString();
        if (in.readByte() == 0) {
            opentableSupport = null;
        } else {
            opentableSupport = in.readInt();
        }
        if (in.readByte() == 0) {
            isZomatoBookRes = null;
        } else {
            isZomatoBookRes = in.readInt();
        }
        mezzoProvider = in.readString();
        if (in.readByte() == 0) {
            isBookFormWebView = null;
        } else {
            isBookFormWebView = in.readInt();
        }
        bookFormWebViewUrl = in.readString();
        bookAgainUrl = in.readString();
        thumb = in.readString();
        photosUrl = in.readString();
        menuUrl = in.readString();
        featuredImage = in.readString();
        if (in.readByte() == 0) {
            hasOnlineDelivery = null;
        } else {
            hasOnlineDelivery = in.readInt();
        }
        if (in.readByte() == 0) {
            isDeliveringNow = null;
        } else {
            isDeliveringNow = in.readInt();
        }
        byte tmpIncludeBogoOffers = in.readByte();
        includeBogoOffers = tmpIncludeBogoOffers == 0 ? null : tmpIncludeBogoOffers == 1;
        deeplink = in.readString();
        if (in.readByte() == 0) {
            isTableReservationSupported = null;
        } else {
            isTableReservationSupported = in.readInt();
        }
        if (in.readByte() == 0) {
            hasTableBooking = null;
        } else {
            hasTableBooking = in.readInt();
        }
        eventsUrl = in.readString();
    }

    public static final Creator<Restaurant> CREATOR = new Creator<Restaurant>() {
        @Override
        public Restaurant createFromParcel(Parcel in) {
            return new Restaurant(in);
        }

        @Override
        public Restaurant[] newArray(int size) {
            return new Restaurant[size];
        }
    };

    public Re getR() {
        return r;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Location_ getLocation() {
        return location;
    }

    public String getCuisines() {
        return cuisines;
    }

    public Integer getAverageCostForTwo() {
        return averageCostForTwo;
    }

    public Integer getPriceRange() {
        return priceRange;
    }

    public UserRating getUserRating() {
        return userRating;
    }

    public String getFeaturedImage() {
        return featuredImage;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(apikey);
        dest.writeString(id);
        dest.writeString(name);
        dest.writeString(url);
        if (switchToOrderMenu == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(switchToOrderMenu);
        }
        dest.writeString(cuisines);
        if (averageCostForTwo == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(averageCostForTwo);
        }
        if (priceRange == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(priceRange);
        }
        dest.writeString(currency);
        if (opentableSupport == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(opentableSupport);
        }
        if (isZomatoBookRes == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(isZomatoBookRes);
        }
        dest.writeString(mezzoProvider);
        if (isBookFormWebView == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(isBookFormWebView);
        }
        dest.writeString(bookFormWebViewUrl);
        dest.writeString(bookAgainUrl);
        dest.writeString(thumb);
        dest.writeString(photosUrl);
        dest.writeString(menuUrl);
        dest.writeString(featuredImage);
        if (hasOnlineDelivery == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(hasOnlineDelivery);
        }
        if (isDeliveringNow == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(isDeliveringNow);
        }
        dest.writeByte((byte) (includeBogoOffers == null ? 0 : includeBogoOffers ? 1 : 2));
        dest.writeString(deeplink);
        if (isTableReservationSupported == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(isTableReservationSupported);
        }
        if (hasTableBooking == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(hasTableBooking);
        }
        dest.writeString(eventsUrl);
    }
}
