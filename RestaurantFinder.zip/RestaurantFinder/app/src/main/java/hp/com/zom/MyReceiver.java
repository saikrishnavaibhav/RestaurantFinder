package hp.com.zom;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class MyReceiver extends BroadcastReceiver {

    public static ConnectionListener connectionListener;

    @Override
    public void onReceive(Context context, Intent intent) {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        boolean conn = networkInfo != null && networkInfo.isConnectedOrConnecting();

        if (connectionListener != null)
            connectionListener.NetworkChanged(conn);
    }

    public static boolean isConnected() {
        ConnectivityManager
                connectivityManager = (ConnectivityManager) ConnectTest.getInstance().getApplicationContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnectedOrConnecting();
    }

    public interface ConnectionListener {
        void NetworkChanged(boolean conn);
    }
}
