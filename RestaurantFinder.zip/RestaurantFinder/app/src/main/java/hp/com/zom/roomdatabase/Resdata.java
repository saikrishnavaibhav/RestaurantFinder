package hp.com.zom.roomdatabase;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;


@Entity(tableName = "favrest")
public class Resdata implements Parcelable {

    @PrimaryKey
    @NonNull
    private String id = "";

    private String image;
    private String resname;
    private String resaddress;
    private String rescity;
    private String avgcost;
    private String rating;
    private String price;
    private String ratingtext;
    private Double latitude, longitude;
    private String cuisines;

    public String getCuisines() {
        return cuisines;
    }

    public void setCuisines(String cuisines) {
        this.cuisines = cuisines;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Resdata() {
    }

    @Ignore
    public Resdata(@NonNull String id, String image, String resname, String resaddress, String rescity, String avgcost, String rating, String price, String ratingtext, String cuisines) {
        this.id = id;
        this.image = image;
        this.resname = resname;
        this.resaddress = resaddress;
        this.rescity = rescity;
        this.avgcost = avgcost;
        this.rating = rating;
        this.price = price;
        this.ratingtext = ratingtext;
        this.cuisines = cuisines;
    }

    private Resdata(Parcel in) {
        id = in.readString();
        image = in.readString();
        resname = in.readString();
        resaddress = in.readString();
        rescity = in.readString();
        avgcost = in.readString();
        rating = in.readString();
        price = in.readString();
        ratingtext = in.readString();
    }

    public static final Creator<Resdata> CREATOR = new Creator<Resdata>() {
        @Override
        public Resdata createFromParcel(Parcel in) {
            return new Resdata(in);
        }

        @Override
        public Resdata[] newArray(int size) {
            return new Resdata[size];
        }
    };

    @NonNull
    public String getId() {
        return id;
    }

    public void setId(@NonNull String id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getResname() {
        return resname;
    }

    public void setResname(String resname) {
        this.resname = resname;
    }

    public String getResaddress() {
        return resaddress;
    }

    public void setResaddress(String resaddress) {
        this.resaddress = resaddress;
    }

    public String getRescity() {
        return rescity;
    }

    public void setRescity(String rescity) {
        this.rescity = rescity;
    }

    public String getAvgcost() {
        return avgcost;
    }

    public void setAvgcost(String avgcost) {
        this.avgcost = avgcost;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getRatingtext() {
        return ratingtext;
    }

    public void setRatingtext(String ratingtext) {
        this.ratingtext = ratingtext;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(image);
        dest.writeString(resname);
        dest.writeString(resaddress);
        dest.writeString(rescity);
        dest.writeString(avgcost);
        dest.writeString(rating);
        dest.writeString(price);
        dest.writeString(ratingtext);
    }
}