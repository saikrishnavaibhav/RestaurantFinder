package hp.com.zom.geocode;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Re {

    @SerializedName("res_id")
    @Expose
    private Integer resId;
    public Integer getResId() {
        return resId;
    }

}